# Wisdom-Shaders
A Minecraft shaderspack. Offers high performance with high quality at the same time.

Requirements&Specifications are on the website.

This shader is in THE APACHE License, more information in LICENSE.TXT

# Official website
https://bc3.moe/wisdom-shaders/

# Versions & Branches

For the stable V3.2 release, download it from the website.

For the beta (now deprecated) V3.99 release, go to the 3.99 branch.

For the latest development release, download the master branch
